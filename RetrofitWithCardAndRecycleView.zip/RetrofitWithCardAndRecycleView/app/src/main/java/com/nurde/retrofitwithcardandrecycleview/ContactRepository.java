package com.nurde.retrofitwithcardandrecycleview;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import android.util.Log;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ContactRepository {
    Retrofit connection = ContactConnection.getInstance();

    private ContactApi contactApi = connection.create(ContactApi.class);

    private MutableLiveData<List<Contact>> allContacts = new MutableLiveData<>();

    public LiveData<List<Contact>> getAllContacts(){
        Call<List<Contact>> call = contactApi.getAllContact();
        call.enqueue(new Callback<List<Contact>>() {
            @Override
            public void onResponse(Call<List<Contact>> call, Response<List<Contact>> response) {
                allContacts.setValue(response.body());
            }

            @Override
            public void onFailure(Call<List<Contact>> call, Throwable t) {
                Log.e("Err : ", t.getMessage());
            }
        });
        return allContacts;
    }

    public  LiveData<List<Contact>> getAllContact() {
        return  allContacts;
    }
}
